# Responsive-Website-Template
# Check the full website here: https://ahmadsabbirchowdhury.github.io/Responsive-Website-Template/index.html
#
Simple front end responsive website using HTML5 and CSS3.
Here I didn't try to make it way too complex. This is just a simple static website template. But we can modify it and make it dynamic.
I already put a "Subscribe To Our Newsletter" option which we can link to a database if we want to make this website dynamic.
